.. Slurm资源管理与作业调度系统安装配置 documentation master file, created by
   sphinx-quickstart on Sat Nov 27 15:58:16 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Slurm资源管理与作业调度系统安装配置
===================================

.. toctree::
   :numbered:
   :maxdepth: 2
   :caption: Contents:

   slurm-install
   contact


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
