.. Ubuntu 22.04下的LDAP认证服务及客户端设置 documentation master file, created by
   sphinx-quickstart on Sun Sep 25 21:32:33 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Ubuntu 22.04下的LDAP认证服务及客户端设置
========================================

.. toctree::
   :maxdepth: 3
   :caption: 目录

   ubuntu-ldap


索引与图表
==========

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
