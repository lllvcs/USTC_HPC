.. 中国科大超级计算中心用户文档 documentation master file, created by
   sphinx-quickstart on Sat Mar  6 13:22:24 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Slurm作业调度系统
=================

.. toctree::
   :maxdepth: 2

   slurm
