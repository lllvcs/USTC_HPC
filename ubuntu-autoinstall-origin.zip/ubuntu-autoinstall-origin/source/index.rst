.. Ubuntu 22.04下的PXE安装服务配置 documentation master file, created by
   sphinx-quickstart on Mon Sep 26 22:18:43 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Ubuntu 22.04下的autoinstall自动安装服务配置
===========================================

.. toctree::
   :maxdepth: 2
   :caption: 目录:

   ubuntu-autoinstall
   contact


索引与图表
==========

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
